﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SE_Assignment
{
    class Catalogue
    {
        private int uniqueID;
        private string name;
        private string description;
        private double price;
        private int unit;
        private string status;
        protected StatusBehaviour statusBehaviour;

        public int UniqueID
        {
            get { return uniqueID; }
            set { uniqueID = value; }
        }
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public string Description
        {
            get { return description; }
            set { description = value; }
        }
        public double Price
        {
            get { return price; }
            set { price = value; }
        }
        public int Unit
        { 
            get { return unit; }
            set { unit = value; }
        }
        public string Status
        {
            get { return status; }
            set { status = value; }
        }

        public Catalogue(int UniqueID, string Name, string Description, double Price, int Unit, string Status, StatusBehaviour statusBehaviour)
        {
            this.UniqueID = UniqueID;
            this.Name = Name;
            this.Description = Description;
            this.Price = Price;
            this.Unit = Unit;
            this.Status = Status;
            this.statusBehaviour = statusBehaviour;

        }


        public void performAvailability()
        {

        }
    }
}
