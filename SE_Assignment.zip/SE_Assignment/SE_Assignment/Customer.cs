﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SE_Assignment
{
    class Customer : Observer
    {
        private int accountNumber;
        private string name;
        private string address;
        private string email;
        private string contactNumber;

        public int AccountNumber
        {
            get { return accountNumber; }
            set { accountNumber = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public string Address
        {
            get { return address; }
            set { address = value; }
        }
        public string Email
        {
            get { return email; }
            set { email = value; }
        }
        public string ContactNumber
        {
            get { return contactNumber; }
            set { contactNumber = value; }
        }
        public void placeOrder()
        {

        }

        public void cancelOrder()
        {

        }

        public void viewOrder()
        {
            
        }

        public void changeStatus()
        {
            Console.WriteLine("Status updated");
        }

    }
}
