﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SE_Assignment
{
    class Payment
    {
        private string mode;
        private DateTime payDateTime;
        private int receiptNo;
        private double payAmt;

        public string Mode
        {
            get { return mode; }
            set { mode = value; }
        }

        public DateTime PayDateTime
        {
            get { return PayDateTime; }
            set { payDateTime = value; }
        }

        public int ReceiptNo
        {
            get { return receiptNo; }
            set { receiptNo = value; }
        }

        public double PayAmt
        {
            get { return payAmt; }
            set { payAmt = value; }
        }
        public Payment(string Mode, DateTime PayDateTime, int ReceiptNo, double PayAmt)
        {
            this.Mode = Mode;
            this.PayDateTime = PayDateTime;
            this.ReceiptNo = ReceiptNo;
            this.PayAmt = PayAmt;
        }
        public void makePayment()
        {

        }
    }
}
