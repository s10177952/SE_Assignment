﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SE_Assignment
{
    class CreditCardPayment : Payment
    {
        private int cardNumber;
        private string cardName;
        private string cardType;
        private int cardCVV;

        public int CardNumber
        {
            get { return cardNumber; }
            set { cardNumber = value; }
        }
        public string CardName
        {
            get { return cardName; }
            set { cardName = value; }
        }
        public string CardType
        {
            get { return cardType; }
            set { cardType = value; }
        }
        public int CardCVV
        {
            get { return cardCVV; }
            set { cardCVV = value; }
        }

        public CreditCardPayment(string Mode, DateTime PayDateTime, int ReceiptNo, double PayAmt, int CardNumber, string CardName, string CardType, int CardCVV) : base(Mode, PayDateTime, ReceiptNo, PayAmt)
        {
            {
                this.Mode = Mode;
                this.PayDateTime = PayDateTime;
                this.ReceiptNo = ReceiptNo;
                this.PayAmt = PayAmt;
                this.CardNumber = CardNumber;
                this.CardName = CardName;
                this.CardType = CardType;
                this.CardCVV = CardCVV;
            }
        }


    }
}
