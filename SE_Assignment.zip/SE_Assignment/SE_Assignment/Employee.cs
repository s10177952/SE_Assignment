﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SE_Assignment
{
    class Employee
    {
        protected string name; //supposed to be private
        protected int id;
        protected string nric;
        protected string gender;
        protected string contactNumber;
        protected DateTime dateJoined;
        protected string status;

        public Employee(int id, string name, string nric, string gender, string contactNumber, DateTime dateJoined, string status)
        {
            this.name = name;
            this.id = id;
            this.nric = nric;
            this.gender = gender;
            this.contactNumber = contactNumber;
            this.dateJoined = dateJoined;
            this.status = status;
            
        }

    }


}
