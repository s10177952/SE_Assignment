﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SE_Assignment
{
    class Dispatcher : Employee
    {
        private double monthlyCommission; //Derived attribute

        public double MonthlyCommission
        {
            get { return monthlyCommission; }
            set { monthlyCommission = value; }
        }
        private string ordersDelivered;

        public string OrdersDelivered
        {
            get { return ordersDelivered; }
            set { ordersDelivered = value; }
        }

        public Dispatcher(int id, string name, string nric, string gender, string contactNumber, DateTime dateJoined, string status, double MonthlyCommission) : base(id, name, nric, gender, contactNumber, dateJoined, status)
        {
            base.id = id;
            this.name = name;
            this.nric = nric;
            this.gender = gender;
            this.contactNumber = contactNumber;
            this.dateJoined = dateJoined;
            this.status = status;
            this.MonthlyCommission = monthlyCommission;
        }

        public int calculateMonthlyCommission()
        {
            return 0; //Not 0
        }
    }
}
