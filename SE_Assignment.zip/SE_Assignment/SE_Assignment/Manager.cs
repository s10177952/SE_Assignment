﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SE_Assignment
{
    class Manager : Employee
    {
        private DateTime startDate;

        public DateTime StartDate
        {
            get { return startDate; }
            set { startDate = value; }
        }



        public Manager(int id, string name, string nric, string gender, string contactNumber, DateTime dateJoined, string status) : base(id, name, nric, gender, contactNumber, dateJoined, status)
        {
            base.id = id;
            this.name = name;
            this.nric = nric;
            this.gender = gender;
            this.contactNumber = contactNumber;
            this.dateJoined = dateJoined;
            this.status = status;
        }

        public void createMenu()
        {

        }

        public void createFoodItem()
        {

        }

        public void updateMenu()
        {

        }

        public void updateFoodItem()
        {

        }

        public void deleteMenu()
        {

        }

        public void deleteFoodItem()
        {

        }

        public void viewOrders()
        {

        }
    }
}
