﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SE_Assignment
{
    class Menu : Catalogue
    {
        private string size;
        private string type;

        public string Size
        {
            get { return size; }
            set { size = value; }
        }

        public string Type
        {
            get { return type; }
            set { type = value; }
        }

        public Menu(int UniqueID, string Name, string Description, double Price, int Unit, string Status, StatusBehaviour statusBehaviour, string Size, string Type)
            : base(UniqueID, Name, Description, Price, Unit, Status, statusBehaviour)
        {
            this.UniqueID = UniqueID;
            this.Name = Name;
            this.Description = Description;
            this.Price = Price;
            this.Unit = Unit;
            this.Status = Status;
            this.statusBehaviour = statusBehaviour;
            this.Size = Size;
            this.Type = Type;

        }
    }
}
