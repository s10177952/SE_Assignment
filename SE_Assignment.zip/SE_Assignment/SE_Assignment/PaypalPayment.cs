﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SE_Assignment
{
    class PaypalPayment : Payment
    {
        private string accountName;

        public string AccountName
        {
            get { return accountName; }
            set { accountName = value; }
        }

        public PaypalPayment(string Mode, DateTime PayDateTime, int ReceiptNo, double PayAmt, string AccountName) : base(Mode, PayDateTime, ReceiptNo, PayAmt)
        {
            this.Mode = Mode;
            this.PayDateTime = PayDateTime;
            this.ReceiptNo = ReceiptNo;
            this.PayAmt = PayAmt;
            this.AccountName = AccountName;
        }
    }
}
