﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SE_Assignment
{
    class Order : Subject
    {
        private int orderNumber;   //put get and set
        private string orderStatus;
        private DateTime dateTimeOfOrder;
        private DateTime dateTimeOrderReady;
        private DateTime dateTimeOrderDelivery;
        private string orderedItems;
        private double deliveryCharge;
        private double totalAmount;
        private double subTotal;
        private double gst;

        public void registerObserver()
        {

        }

        public void removeObserver()
        {

        }

        public void notifyObserver()
        {

        }

        public void registerObserver(Observer o)
        {
            o.changeStatus();
        }
        public void removeObserver(Observer o)
        {
            o.changeStatus();
        }
        public void notifyObserver(Observer o)
        {
            o.changeStatus();
        }
        public void calculateTotal()
        {

        }

        public void changeStatus()
        {

        }

        public void archiveOrder()
        {

        }



    }
}
